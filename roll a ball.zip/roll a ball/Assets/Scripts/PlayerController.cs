﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;



public class PlayerController : MonoBehaviour{

		public float speed;
        public Text countText;
        public Text winText;

    	// variable para mantener la referencia
    	private Rigidbody rb;
        private int count;

    	void Start ()
    	{
    		rb = GetComponent<Rigidbody>();
            count = 0;
            SetCountText();
            winText.text = "";
    	}
	void FixedUpdate ()
	{
    	float moveHorizontal = Input.GetAxis("Horizontal");
    	float moveVertical = Input.GetAxis("Vertical");

    	// se crea la variablepara unir moverhorizontal y Vector3
    	// (x, y, z) determinan la direccion de la fuerza

    	// Vector3 movement= new Vector3 (x, y, z);
    	// moverhorizontal = en el eje x izquierda y derecha
    	// 0.0f no queremos que se mueba hacia arriba...
    	Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

    	rb.AddForce (movement * speed);
    }

    // Destroy everything that enters the trigger
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            // incrementar a medida que recoge obgetos
            SetCountText();
        }
    }
    void SetCountText()
    {
        countText.text = "Count: "+ count.ToString ();
        if (count >= 28)
        {
            winText.text = "You Win!";
        // }else if (count <= 12){
        //     winText.text = "You not Win";
         }
    }
}



// Destroy(other.gameObject);
// if (other.gameObject.CompareTag("Player"))
//     gameObject.SetActive(false);